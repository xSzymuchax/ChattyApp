import './GamesPanel.css'

function GamesPanel({children}){
    return(
        <div className='games-panel'>
            <div className='toggle-panel-switch' />
        </div>
    )
}

export default GamesPanel