import { useEffect, useState } from 'react'
import './ChatMessage.css'

function ChatMessage({sender_id}) {
    const [isMyMessage, setIsMyMessage] = useState(false);

    //TODO - change 1 into user id
    useEffect(() => {
        setIsMyMessage(sender_id === 1);
    }, [sender_id])

    return (
        <div 
        className='chat-message'
        style={{
            "--margin-left-value": `${isMyMessage ? '25%' : '10px'}`
        }}>
            RANDOM MESSAGE! YEYEYE
            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaa aaaaaaaaaaaaaaaa 
        </div>
    )
}

export default ChatMessage